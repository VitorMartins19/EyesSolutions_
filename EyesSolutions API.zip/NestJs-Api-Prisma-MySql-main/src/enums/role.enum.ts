export enum Role {
  User = 1,
  Admin = 2,
}
